import GLCM
import learner
import morphology
import statistics